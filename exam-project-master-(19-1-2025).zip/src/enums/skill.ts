export enum skills {
  Reading = 1,
  Listening = 2,
  Writing = 3,
  Speaking = 4,
}
