export const BASE_IMG_URL =
  "https://sah-platform-api-egghayfcc4ddeuae.canadacentral-01.azurewebsites.net";
